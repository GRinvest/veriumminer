#!/usr/bin/env bash

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME
echo -n > $CUSTOM_CONFIG_FILENAME
echo "{" >> $CUSTOM_CONFIG_FILENAME

if [[ ! -z $CUSTOM_USER_CONFIG ]]; then
  while read -r line; do
    [[ -z $line ]] && continue
    echo $line >> $CUSTOM_CONFIG_FILENAME
  done <<< "$CUSTOM_USER_CONFIG"
else
  echo "NOT  CUSTOM_USER_CONFIG"
fi

[[ ! -z ${CUSTOM_URL} ]] && echo "  \"url\": \"stratum+tcp://${CUSTOM_URL}\"," >> $CUSTOM_CONFIG_FILENAME
[[ ! -z ${CUSTOM_TEMPLATE} ]] && echo "  \"user\": \"${CUSTOM_TEMPLATE}\"," >> $CUSTOM_CONFIG_FILENAME
[[ ! -z ${CUSTOM_PASS} ]] && echo "  \"pass\": \"${CUSTOM_PASS}\"" >> $CUSTOM_CONFIG_FILENAME

echo "}" >> $CUSTOM_CONFIG_FILENAME