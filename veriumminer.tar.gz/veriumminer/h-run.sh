#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf


./cpuminer -c cpuminer.conf  2>&1 | tee --append $CUSTOM_LOG_BASENAME.log
