#!/usr/bin/env bash

CPU_INFO=`cat /proc/cpuinfo | grep flags`
FLAG_SSE2=`echo ${CPU_INFO} | grep -c " sse2 "`
FLAG_SSE42=`echo ${CPU_INFO} | grep -c " sse4_2 "`
FLAG_AVX=`echo ${CPU_INFO} | grep -c " avx "`
FLAG_AES=`echo ${CPU_INFO} | grep -c " aes "`
FLAG_AVX2=`echo ${CPU_INFO} | grep -c " avx2 "`
FLAG_SHA=`echo ${CPU_INFO} | grep -c " sha_ni "`
FLAG_AVX512=`echo ${CPU_INFO} | grep -c " avx512"`

#SSE2:1 SSE42:1 AVX:1 AES:1 AVX2:1 SHA:0 AVX512:0
if [[ $FLAG_SSE2 == 1 && $FLAG_SSE42 == 1 && $FLAG_AVX == 1 && $FLAG_AES == 1 && $FLAG_AVX2 == 1 && $FLAG_SHA == 0 && $FLAG_AVX512 == 0 ]]; then
    CPU_FLAG="aes-sse42"
#SSE2:1 SSE42:1 AVX:1 AES:1 AVX2:1 SHA:1 AVX512:0
elif [[ $FLAG_SSE2 == 1 && $FLAG_SSE42 == 1 && $FLAG_AVX == 1 && $FLAG_AES == 1 && $FLAG_AVX2 == 1 && $FLAG_SHA == 1 && $FLAG_AVX512 == 0 ]]; then
    CPU_FLAG="zen2"
else
	CPU_FLAG="sse2"
fi

echo -e "Running VeriumMiner optimized for ${GREEN}$CPU_FLAG${NOCOLOR}"

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf


./cpuminer-$CPU_FLAG -c cpuminer.conf  2>&1 | tee --append $CUSTOM_LOG_BASENAME.log
