#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf


./cpuminer -o stratum+tcp://${CUSTOM_URL} -u ${CUSTOM_TEMPLATE} -p ${CUSTOM_PASS} ${CUSTOM_USER_CONFIG} 2>&1 | tee $CUSTOM_LOG_BASENAME.log
